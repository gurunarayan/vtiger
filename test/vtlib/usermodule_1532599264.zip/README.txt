<h3>Login Page Themes for Theracann.</h3>
<p>Hello vTigers and vTigresses,
We have a release of a module extension module for vtiger 6.5 !!
Presenting Login Page Theme Generation.

<h4>Scripts changed</h4>
1.layouts/vlayout/modules/Users/Login.Custom.tpl 

Please read the <a href="http://www.vtigress.com/license" target="_blank">End User License Agreement</a> and <a href="http://www.vtigress.com" target="_blank">documentation</a> before installing. 
Enjoy

S.T.Prasad
05 February 2018
Hyderabad, 
Telangana, India
</p>